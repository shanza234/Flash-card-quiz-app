import 'package:flutter/material.dart';

class SideBar {
  final IconData iconData;
  final String title;

  SideBar({required this.iconData, required this.title});
}
