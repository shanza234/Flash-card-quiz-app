class GraphSpots {
  final double x;
  final double y;

  GraphSpots({required this.x, required this.y});
}
